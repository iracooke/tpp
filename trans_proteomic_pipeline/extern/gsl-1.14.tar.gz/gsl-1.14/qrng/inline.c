/* Author: G. Jungman
 */
#include <config.h>
#include <stdlib.h>
#include <string.h>
#include <gsl/gsl_errno.h>

/* Compile all the inline functions */

#define COMPILE_INLINE_STATIC
#include "build.h"
#include <gsl/gsl_qrng.h>

